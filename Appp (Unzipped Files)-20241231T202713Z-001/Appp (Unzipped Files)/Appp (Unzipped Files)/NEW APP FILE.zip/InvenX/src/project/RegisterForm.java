/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

import Connection.DBConnection;
import java.awt.Color;
import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;


public class RegisterForm extends javax.swing.JFrame {
    
    private PreparedStatement ps;
    private ResultSet rs;
    private Connection connection;
    private String username,password;
    public RegisterForm() {
        initComponents();
        this.setLocationRelativeTo(this);
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        usernameTextFeild1 = new javax.swing.JLabel();
        jTextFieldUsername = new javax.swing.JTextField();
        jLabelUsername = new javax.swing.JLabel();
        usernameTextFeild = new javax.swing.JLabel();
        jTextFieldPassword = new javax.swing.JPasswordField();
        jLabelPassword = new javax.swing.JLabel();
        jButtonRegister = new javax.swing.JButton();
        jButtonCancel = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        usernameTextFeild1.setBackground(new java.awt.Color(255, 255, 255));
        usernameTextFeild1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        usernameTextFeild1.setText("Username");

        jTextFieldUsername.setBackground(new java.awt.Color(204, 204, 204));
        jTextFieldUsername.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jTextFieldUsername.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTextFieldUsernameMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jTextFieldUsernameMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jTextFieldUsernameMouseExited(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                jTextFieldUsernameMouseReleased(evt);
            }
        });

        jLabelUsername.setForeground(new java.awt.Color(255, 0, 51));

        usernameTextFeild.setBackground(new java.awt.Color(255, 255, 255));
        usernameTextFeild.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        usernameTextFeild.setText("Password");

        jTextFieldPassword.setBackground(new java.awt.Color(204, 204, 204));
        jTextFieldPassword.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jTextFieldPassword.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jTextFieldPasswordMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jTextFieldPasswordMouseExited(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                jTextFieldPasswordMouseReleased(evt);
            }
        });
        jTextFieldPassword.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextFieldPasswordActionPerformed(evt);
            }
        });

        jLabelPassword.setForeground(new java.awt.Color(255, 0, 51));

        jButtonRegister.setBackground(new java.awt.Color(0, 255, 51));
        jButtonRegister.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButtonRegister.setForeground(new java.awt.Color(255, 255, 255));
        jButtonRegister.setText("Submit");
        jButtonRegister.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonRegisterActionPerformed(evt);
            }
        });
        jButtonRegister.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jButtonRegisterKeyPressed(evt);
            }
        });

        jButtonCancel.setBackground(new java.awt.Color(255, 0, 51));
        jButtonCancel.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButtonCancel.setForeground(new java.awt.Color(255, 255, 255));
        jButtonCancel.setText("Cancel");
        jButtonCancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonCancelActionPerformed(evt);
            }
        });
        jButtonCancel.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jButtonCancelKeyPressed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Register Now");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(jButtonCancel)
                                .addGap(18, 18, 18)
                                .addComponent(jButtonRegister))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(usernameTextFeild, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabelPassword, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(0, 106, Short.MAX_VALUE))
                                    .addComponent(jTextFieldPassword)))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                .addComponent(usernameTextFeild1, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jTextFieldUsername)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabelUsername, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(0, 0, Short.MAX_VALUE)))))
                        .addGap(28, 28, 28))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap())))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(27, 27, 27)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(usernameTextFeild1, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextFieldUsername, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabelUsername, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(usernameTextFeild, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextFieldPassword, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabelPassword, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButtonRegister, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButtonCancel, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(45, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTextFieldUsernameMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTextFieldUsernameMouseClicked

    }//GEN-LAST:event_jTextFieldUsernameMouseClicked

    private void jTextFieldUsernameMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTextFieldUsernameMouseEntered
        jTextFieldUsername.setBackground(Color.white);
    }//GEN-LAST:event_jTextFieldUsernameMouseEntered

    private void jTextFieldUsernameMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTextFieldUsernameMouseExited
        jTextFieldUsername.setBackground(new Color(0xCCCCCC));
    }//GEN-LAST:event_jTextFieldUsernameMouseExited

    private void jTextFieldUsernameMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTextFieldUsernameMouseReleased
        jLabelUsername.setText("");
    }//GEN-LAST:event_jTextFieldUsernameMouseReleased

    private void jTextFieldPasswordMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTextFieldPasswordMouseEntered
        jTextFieldPassword.setBackground(Color.white);
    }//GEN-LAST:event_jTextFieldPasswordMouseEntered

    private void jTextFieldPasswordMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTextFieldPasswordMouseExited
        jTextFieldPassword.setBackground(new Color(0xCCCCCC));
    }//GEN-LAST:event_jTextFieldPasswordMouseExited

    private void jTextFieldPasswordMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTextFieldPasswordMouseReleased
        jLabelPassword.setText("");
    }//GEN-LAST:event_jTextFieldPasswordMouseReleased

    private void jTextFieldPasswordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldPasswordActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextFieldPasswordActionPerformed

    private void jButtonRegisterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonRegisterActionPerformed
        if(jTextFieldUsername.getText().trim().isEmpty()&&jTextFieldPassword.getText().trim().isEmpty()){
            jLabelUsername.setText("Username is Empty!");
            jLabelPassword.setText("Password is Empty!");
        }else if(jTextFieldUsername.getText().trim().isEmpty()){
            jLabelUsername.setText("Username is Empty!");
        }else if(jTextFieldPassword.getText().trim().isEmpty()){
            jLabelPassword.setText("Password is Empty!");
        } else{
            try {
                userCaredentials();
            } catch (SQLException ex) {
                Logger.getLogger(RegisterForm.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }//GEN-LAST:event_jButtonRegisterActionPerformed

    private void jButtonRegisterKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jButtonRegisterKeyPressed
        
    }//GEN-LAST:event_jButtonRegisterKeyPressed

    private void jButtonCancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonCancelActionPerformed
        int n = JOptionPane.showConfirmDialog(
            null,
            "Are you sure!",
            "Close",
            JOptionPane.YES_NO_OPTION);
        if(n==JOptionPane.YES_NO_OPTION){
            try {
                LoginForm loginForm = new LoginForm();
                loginForm.setVisible(true);
                this.dispose();
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(RegisterForm.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SQLException ex) {
                Logger.getLogger(RegisterForm.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }//GEN-LAST:event_jButtonCancelActionPerformed

    private void jButtonCancelKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jButtonCancelKeyPressed

    }//GEN-LAST:event_jButtonCancelKeyPressed

    public void userCaredentials() throws SQLException{
        try {
                PreparedStatement p;
                connection = DBConnection.connect();
                p = connection.prepareStatement("Select *From UserCredentials Where username='"
                        + jTextFieldUsername.getText()+"'");
                ResultSet r= p.executeQuery();
                if(r.next()==true){
                    jLabelPassword.setText("User Already exist...");
                    jTextFieldUsername.setText("");
                    jTextFieldPassword.setText("");
                 }else{
                    username = jTextFieldUsername.getText();
                    password = new String(jTextFieldPassword.getPassword());
                    connection = DBConnection.connect();
                    ps = connection.prepareStatement("insert into UserCredentials(user_id,"
                            + "username,"
                            + "password) "
                            + "values (?,?,?); ");
                    ps.setString(2, username);
                    ps.setString(3, password);
                    ps.executeUpdate();
                    LoginForm loginForm = new LoginForm();
                    loginForm.setVisible(true);
                    this.dispose();
                }
        } catch (ClassNotFoundException | SQLException | HeadlessException e) {
        } finally{
            connection.close();
        }
    }
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(RegisterForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(RegisterForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(RegisterForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(RegisterForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new RegisterForm().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonCancel;
    private javax.swing.JButton jButtonRegister;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabelPassword;
    private javax.swing.JLabel jLabelUsername;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPasswordField jTextFieldPassword;
    private javax.swing.JTextField jTextFieldUsername;
    private javax.swing.JLabel usernameTextFeild;
    private javax.swing.JLabel usernameTextFeild1;
    // End of variables declaration//GEN-END:variables
}
