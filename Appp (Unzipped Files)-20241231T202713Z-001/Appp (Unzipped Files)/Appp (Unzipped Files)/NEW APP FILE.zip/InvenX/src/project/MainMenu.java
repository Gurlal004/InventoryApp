package project;


import java.awt.Color;
import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.RowFilter;
import javax.swing.SwingWorker;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import models.Products;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartFrame;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PiePlot;
import org.jfree.data.general.DefaultPieDataset;
import Connection.DBConnection;

public final class MainMenu extends javax.swing.JFrame {

    private PreparedStatement ps;
    private ResultSet rs;
    Connection connection;
    double sellingTotal;
    SwingWorker sw;
    public MainMenu() throws ClassNotFoundException, SQLException {
        initComponents();
        this.setLocationRelativeTo(this);
        DefaultTableModel model = (DefaultTableModel) jTableMain.getModel();
        model.setRowCount(0);
        tableAlignment();
        sw = new SwingWorker() {

            @Override
            protected Object doInBackground() throws Exception {
                showProducts();
                return null;
            }
        };
        sw.execute();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jButtonInsert = new javax.swing.JButton();
        jButtonUpdate = new javax.swing.JButton();
        jButtonPrint = new javax.swing.JButton();
        jButtonDelete = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTableMain = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jTextFieldSearh = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabelLogOut = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        jButtonInsert.setText("INSERT");
        jButtonInsert.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButtonInsertMouseClicked(evt);
            }
        });

        jButtonUpdate.setText("EDIT");
        jButtonUpdate.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButtonUpdateMouseClicked(evt);
            }
        });

        jButtonPrint.setText("Print Bill");
        jButtonPrint.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButtonPrintMouseClicked(evt);
            }
        });

        jButtonDelete.setText("DELETE");
        jButtonDelete.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButtonDeleteMouseClicked(evt);
            }
        });

        jTableMain.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jTableMain.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Product Name", "Buying Price", "Selling Price", "No of Products"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTableMain.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jTableMain.setRowHeight(20);
        jScrollPane1.setViewportView(jTableMain);
        if (jTableMain.getColumnModel().getColumnCount() > 0) {
            jTableMain.getColumnModel().getColumn(0).setResizable(false);
            jTableMain.getColumnModel().getColumn(0).setPreferredWidth(40);
            jTableMain.getColumnModel().getColumn(1).setResizable(false);
            jTableMain.getColumnModel().getColumn(1).setPreferredWidth(150);
            jTableMain.getColumnModel().getColumn(2).setResizable(false);
            jTableMain.getColumnModel().getColumn(2).setPreferredWidth(100);
            jTableMain.getColumnModel().getColumn(3).setResizable(false);
            jTableMain.getColumnModel().getColumn(3).setPreferredWidth(100);
            jTableMain.getColumnModel().getColumn(4).setResizable(false);
            jTableMain.getColumnModel().getColumn(4).setPreferredWidth(80);
        }

        jButton1.setText("Show Graph");
        jButton1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton1MouseClicked(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel1.setText("Search");

        jTextFieldSearh.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jTextFieldSearhKeyReleased(evt);
            }
        });

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/logo_small.jpg"))); // NOI18N

        jLabelLogOut.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        jLabelLogOut.setForeground(new java.awt.Color(102, 102, 102));
        jLabelLogOut.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabelLogOut.setText("Log Out");
        jLabelLogOut.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabelLogOutMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jButtonInsert)
                        .addGap(18, 18, 18)
                        .addComponent(jButtonUpdate)
                        .addGap(18, 18, 18)
                        .addComponent(jButtonDelete)
                        .addGap(18, 18, 18)
                        .addComponent(jButtonPrint)
                        .addGap(18, 18, 18)
                        .addComponent(jButton1)
                        .addGap(184, 184, 184)
                        .addComponent(jLabelLogOut))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jTextFieldSearh, javax.swing.GroupLayout.PREFERRED_SIZE, 409, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 250, Short.MAX_VALUE))
                    .addComponent(jScrollPane1))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel2)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel1)
                        .addComponent(jTextFieldSearh, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 398, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabelLogOut, javax.swing.GroupLayout.DEFAULT_SIZE, 36, Short.MAX_VALUE)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(jButtonDelete, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButtonPrint, javax.swing.GroupLayout.DEFAULT_SIZE, 36, Short.MAX_VALUE)
                        .addComponent(jButtonInsert, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButtonUpdate, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonInsertMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonInsertMouseClicked
        try {
            DataMaintain insertDataForm = new DataMaintain();
            insertDataForm.setVisible(true);
            this.dispose();
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(MainMenu.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButtonInsertMouseClicked

    private void jButtonDeleteMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonDeleteMouseClicked
        new DeleteThread().run();
    }//GEN-LAST:event_jButtonDeleteMouseClicked

    private void jTextFieldSearhKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextFieldSearhKeyReleased
        DefaultTableModel model =(DefaultTableModel) jTableMain.getModel();
        String search = jTextFieldSearh.getText();
        TableRowSorter<DefaultTableModel> tr = new TableRowSorter<>(model);
        jTableMain.setRowSorter(tr);
        tr.setRowFilter(RowFilter.regexFilter(search));
    }//GEN-LAST:event_jTextFieldSearhKeyReleased

    private void jButtonUpdateMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonUpdateMouseClicked
        DefaultTableModel model = (DefaultTableModel)jTableMain.getModel();
        int selectedRowsIndex = jTableMain.getSelectedRow();
        int id = Integer.parseInt(model.getValueAt(selectedRowsIndex, 0).toString());
        
        try {
            connection = DBConnection.connect();
            ps = connection.prepareStatement("select *from Products where p_id = '"+id+"';");
            rs = ps.executeQuery();
            while(rs.next()){
            DataMaintain insertDataForm = new DataMaintain(id,rs.getString("product_name"),rs.getString("buying_price")
                    ,rs.getString("selling_price"),rs.getString("product_left"));
            insertDataForm.setVisible(true);
            this.dispose();
            }
        } catch (ClassNotFoundException | SQLException e) {
            System.err.println(e.getMessage());
        }finally{
            try {
                connection.close();
                ps.close();
                rs.close();
            } catch (Exception e) {
            }
        }
//        String name = model.getValueAt(selectedRowsIndex, 1).toString();
//        String buynigPrice = model.getValueAt(selectedRowsIndex, 2).toString();
//        String sellingPrice = model.getValueAt(selectedRowsIndex, 3).toString();
//        String productsLeft = model.getValueAt(selectedRowsIndex, 4).toString();
//        DataMaintain insertDataForm = new DataMaintain(id,name,buynigPrice,sellingPrice,productsLeft);
//        insertDataForm.setVisible(true);
//        this.dispose();
    }//GEN-LAST:event_jButtonUpdateMouseClicked

    private void jButtonPrintMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonPrintMouseClicked
        PrintBill printDataForm = new PrintBill();
            printDataForm.setVisible(true);
            this.dispose();
    }//GEN-LAST:event_jButtonPrintMouseClicked

    private void jButton1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton1MouseClicked
        graphForProfit();
    }//GEN-LAST:event_jButton1MouseClicked

    private void jLabelLogOutMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabelLogOutMouseClicked
        try {
            LoginForm loginForm = new LoginForm();
            loginForm.setVisible(true);
            this.dispose();
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(MainMenu.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(MainMenu.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jLabelLogOutMouseClicked

    public ArrayList<Products> productList() throws ClassNotFoundException, SQLException{
        ArrayList<Products> productsList = new ArrayList<>();
        connection = DBConnection.connect();
        try{
                ps = connection.prepareStatement("select *from Products");
                rs = ps.executeQuery();
                Products products;
                while(rs.next()){
                    products = new Products(rs.getInt("p_id"),
                            rs.getString("product_name"),
                            rs.getString("buying_price"),
                            rs.getString("selling_price"),
                            rs.getString("product_left"));
                    productsList.add(products);
                }
        }catch (SQLException e) {
                JOptionPane.showMessageDialog(null,e.getMessage());
            }
        finally{
            try {
                ps.close();
                rs.close();
                connection.close();
                System.out.print("connection is closed");
                } catch (SQLException ex) {
                    Logger.getLogger(MainMenu.class.getName()).log(Level.SEVERE, null, ex);
                }
            
        }
        return productsList;
    }
    
    public void showProducts(){
        try{
        ArrayList<Products> list = productList();
        DefaultTableModel model = (DefaultTableModel) jTableMain.getModel();
        Object[] row = new Object[5];
        list.stream().map((list1) -> {
            row[0] = list1.getId();
            return list1;
            }).map((list1) -> {
                row[1] = list1.getName();
                return list1;
            }).map((list1) -> {
                row[2] = list1.getBuyPrice()+" $";
                return list1;
            }).map((list1) -> {
                row[3] = list1.getSellPrice()+" $";
                return list1;
            }).map((list1) -> {
                row[4] = list1.getNoOfProducts();
                return list1;
            }).forEach((_item) -> {
                model.addRow(row);
            });
        }catch(ClassNotFoundException | SQLException e){
            
        }
    }
    
    public void deleteProductRecords() throws ClassNotFoundException{
        int column = 0;
        int row = jTableMain.getSelectedRow();
        String value = jTableMain.getModel().getValueAt(row, column).toString();
        try {
            if(value.equals("")){
                JOptionPane.showMessageDialog(null, "Please Enter ID...");
            }else {
                connection = DBConnection.connect();
                ps=connection.prepareStatement("delete from Products where p_id="+value);
                ps.executeUpdate();
                DefaultTableModel model= (DefaultTableModel)jTableMain.getModel();
                model.setRowCount(0);
                showProducts();
                JOptionPane.showMessageDialog(null, "Recorde is Deleted...");
            }
        } catch (HeadlessException | SQLException e) {
            JOptionPane.showMessageDialog(null, e);
        } finally{
                try {
                    connection.close();
                    ps.close();
                } catch (SQLException ex) {
                    Logger.getLogger(MainMenu.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
    }
    
    public void graphForProfit(){
        DefaultPieDataset dataSet = new DefaultPieDataset();
        try {
            connection = DBConnection.connect();
            ps = connection.prepareStatement("Select sellings from Sellings_Profit");
            rs = ps.executeQuery();
            double sellings = 0;
            while(rs.next()){
                sellings =sellings + Double.parseDouble(rs.getString("sellings"));
            }
            dataSet.setValue("Sellings",sellings);
            } catch (SQLException | ClassNotFoundException ex) {
            Logger.getLogger(MainMenu.class.getName()).log(Level.SEVERE, null, ex);
        } finally{
            try {
                ps.close();
                rs.close();
                connection.close();
            } catch (Exception e) {
            }
        }
        try {
            connection = DBConnection.connect();
            PreparedStatement p1 = connection.prepareStatement("Select profit from Sellings_Profit");
            rs = p1.executeQuery();
            double profit = 0;
            while(rs.next()){
                profit =profit + Double.parseDouble(rs.getString("profit"));
                
            }
            dataSet.setValue("Profit",profit);
        } catch (ClassNotFoundException | SQLException | NumberFormatException e) {
        }finally{
            try {
                rs.close();
                connection.close();
            } catch (Exception e) {
            }
        }
            
            
            JFreeChart pieChart =ChartFactory.createPieChart("pie chart", dataSet, true, true, true);
            PiePlot plotChart = (PiePlot)pieChart.getPlot();
            ChartFrame frame = new ChartFrame("pie chart", pieChart);
            frame.setVisible(true);
            frame.setSize(450, 500);
            frame.setBackground(Color.WHITE);
            frame.setLocationRelativeTo(null);
        
    }
    
    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MainMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        
        //</editor-fold>

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run(){
            try {
                new MainMenu().setVisible(true);
            } catch (ClassNotFoundException | SQLException ex) {
                Logger.getLogger(MainMenu.class.getName()).log(Level.SEVERE, null, ex);
            }
            }
        });
    }
    
    public class DeleteThread implements Runnable{

        @Override
        public void run() {
            try {
                deleteProductRecords();
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(MainMenu.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
    }
    
    public void tableAlignment(){
        DefaultTableCellRenderer rightRenderer = new DefaultTableCellRenderer();
        rightRenderer.setHorizontalAlignment(JLabel.RIGHT);
        for (int i=2;i<=4;i++){
            jTableMain.getColumnModel().getColumn(i).setCellRenderer(rightRenderer);
        }
        
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);
            jTableMain.getColumnModel().getColumn(0).setCellRenderer(centerRenderer);
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButtonDelete;
    private javax.swing.JButton jButtonInsert;
    private javax.swing.JButton jButtonPrint;
    private javax.swing.JButton jButtonUpdate;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabelLogOut;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTableMain;
    private javax.swing.JTextField jTextFieldSearh;
    // End of variables declaration//GEN-END:variables
}
// javax and all gui things = data members