package models;

public class Printables {
    int id;
    String date,productName,sellings,profit;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getSellings() {
        return sellings;
    }

    public void setSellings(String sellings) {
        this.sellings = sellings;
    }

    public String getProfit() {
        return profit;
    }

    public void setProfit(String profit) {
        this.profit = profit;
    }

    public Printables(int id, String date, String productName, String sellings, String profit) {
        this.id = id;
        this.date = date;
        this.productName = productName;
        this.sellings = sellings;
        this.profit = profit;
    }
}
