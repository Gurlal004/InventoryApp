package models;

public class Products {
    int id;
    String name,buyPrice,sellPrice,noOfProducts;

    public Products(int id, String name, String buyPrice, String sellPrice, String noOfProducts) {
        this.id = id;
        this.name = name;
        this.buyPrice = buyPrice;
        this.sellPrice = sellPrice;
        this.noOfProducts = noOfProducts;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBuyPrice() {
        return buyPrice;
    }

    public void setBuyPrice(String buyPrice) {
        this.buyPrice = buyPrice;
    }

    public String getSellPrice() {
        return sellPrice;
    }

    public void setSellPrice(String sellPrice) {
        this.sellPrice = sellPrice;
    }

    public String getNoOfProducts() {
        return noOfProducts;
    }

    public void setNoOfProducts(String noOfProducts) {
        this.noOfProducts = noOfProducts;
    }
}
