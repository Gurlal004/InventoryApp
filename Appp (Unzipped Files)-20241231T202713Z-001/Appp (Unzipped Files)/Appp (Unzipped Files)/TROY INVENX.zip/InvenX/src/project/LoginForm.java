package project;


import java.awt.Color;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
//import java.time.Clock.system;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SwingWorker;
import Connection.DBConnection;
/**
 *
 * @author honey's here
 */
/**
 *
 * @author honey's here
 */

public final class LoginForm extends javax.swing.JFrame {
    
    private PreparedStatement ps;
    private ResultSet rs;
    private Connection connection;
    public LoginForm() throws ClassNotFoundException, SQLException {
        initComponents();
        DBConnection.DbChecker();
        this.setLocationRelativeTo(this);
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jPanel2 = new javax.swing.JPanel();
        usernameTextFeild = new javax.swing.JLabel();
        usernameTextFeild1 = new javax.swing.JLabel();
        jTextFieldUsername = new javax.swing.JTextField();
        jTextFieldPassword = new javax.swing.JPasswordField();
        jButtonLogin = new javax.swing.JButton();
        jButtonCancel = new javax.swing.JButton();
        jLabelPassword = new javax.swing.JLabel();
        jLabelUsername = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jButtonRegisterNow = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        usernameTextFeild.setBackground(new java.awt.Color(255, 255, 255));
        usernameTextFeild.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        usernameTextFeild.setText("Password");

        usernameTextFeild1.setBackground(new java.awt.Color(255, 255, 255));
        usernameTextFeild1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        usernameTextFeild1.setText("Username");

        jTextFieldUsername.setBackground(new java.awt.Color(204, 204, 204));
        jTextFieldUsername.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jTextFieldUsername.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTextFieldUsernameMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jTextFieldUsernameMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jTextFieldUsernameMouseExited(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                jTextFieldUsernameMouseReleased(evt);
            }
        });

        jTextFieldPassword.setBackground(new java.awt.Color(204, 204, 204));
        jTextFieldPassword.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jTextFieldPassword.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jTextFieldPasswordMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jTextFieldPasswordMouseExited(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                jTextFieldPasswordMouseReleased(evt);
            }
        });
        jTextFieldPassword.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextFieldPasswordActionPerformed(evt);
            }
        });

        jButtonLogin.setBackground(new java.awt.Color(0, 102, 255));
        jButtonLogin.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButtonLogin.setForeground(new java.awt.Color(255, 255, 255));
        jButtonLogin.setText("Login");
        jButtonLogin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonLoginActionPerformed(evt);
            }
        });
        jButtonLogin.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jButtonLoginKeyPressed(evt);
            }
        });

        jButtonCancel.setBackground(new java.awt.Color(255, 0, 51));
        jButtonCancel.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButtonCancel.setForeground(new java.awt.Color(255, 255, 255));
        jButtonCancel.setText("Cancel");
        jButtonCancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonCancelActionPerformed(evt);
            }
        });
        jButtonCancel.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jButtonCancelKeyPressed(evt);
            }
        });

        jLabelPassword.setForeground(new java.awt.Color(255, 0, 51));

        jLabelUsername.setForeground(new java.awt.Color(255, 0, 51));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/logo_small.jpg"))); // NOI18N

        jButtonRegisterNow.setBackground(new java.awt.Color(0, 255, 51));
        jButtonRegisterNow.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButtonRegisterNow.setForeground(new java.awt.Color(255, 255, 255));
        jButtonRegisterNow.setText("Register Now");
        jButtonRegisterNow.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonRegisterNowActionPerformed(evt);
            }
        });
        jButtonRegisterNow.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jButtonRegisterNowKeyPressed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(63, 63, 63)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(usernameTextFeild1, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTextFieldUsername)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabelUsername, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE))))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addComponent(usernameTextFeild, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabelPassword, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addComponent(jTextFieldPassword))))
                .addGap(90, 90, 90))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 71, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addComponent(jButtonCancel, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButtonLogin, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addComponent(jButtonRegisterNow)
                        .addGap(35, 35, 35))))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(usernameTextFeild1, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextFieldUsername, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabelUsername, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(usernameTextFeild, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextFieldPassword, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabelPassword, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(13, 13, 13)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButtonCancel, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButtonLogin, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addComponent(jButtonRegisterNow, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel1))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTextFieldPasswordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldPasswordActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextFieldPasswordActionPerformed

    private void jButtonCancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonCancelActionPerformed
        int n = JOptionPane.showConfirmDialog(
            null,
            "Are you sure!",
            "Close",
            JOptionPane.YES_NO_OPTION);
        if(n==JOptionPane.YES_NO_OPTION){
         System.exit(0);  
        }
    }//GEN-LAST:event_jButtonCancelActionPerformed

    private void jButtonLoginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonLoginActionPerformed
        
        if(jTextFieldUsername.getText().trim().isEmpty()&&jTextFieldPassword.getText().trim().isEmpty()){
            jLabelUsername.setText("Username is Empty!");
            jLabelPassword.setText("Password is Empty!");
        }else if(jTextFieldUsername.getText().trim().isEmpty()){
            jLabelUsername.setText("Username is Empty!");
        }else if(jTextFieldPassword.getText().trim().isEmpty()){
            jLabelPassword.setText("Password is Empty!");
        }
        try {
            PreparedStatement p;
                connection = DBConnection.connect();
                p = connection.prepareStatement("Select *From UserCredentials Where username='"
                        + jTextFieldUsername.getText()+"'");
                ResultSet r= p.executeQuery();
                if(r.next()==true){
                    password = r.getString("password");
                 }
        } catch (ClassNotFoundException | SQLException e) {
        }
        
        username = jTextFieldUsername.getText();
        if(new String(jTextFieldPassword.getPassword()).equals(password)){
            
                try {
                    MainMenu main = new MainMenu();
                    main.setVisible(true);
                } catch (ClassNotFoundException | SQLException ex) {
                    Logger.getLogger(LoginForm.class.getName()).log(Level.SEVERE, null, ex);
                }
            
            this.dispose();
        }else {
            JOptionPane.showMessageDialog(null, "Login Unsuccessful");
        }
    }//GEN-LAST:event_jButtonLoginActionPerformed

    private void jTextFieldUsernameMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTextFieldUsernameMouseClicked

    }//GEN-LAST:event_jTextFieldUsernameMouseClicked

    private void jTextFieldUsernameMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTextFieldUsernameMouseReleased
        jLabelUsername.setText("");
    }//GEN-LAST:event_jTextFieldUsernameMouseReleased

    private void jTextFieldUsernameMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTextFieldUsernameMouseExited
        jTextFieldUsername.setBackground(new Color(0xCCCCCC));
    }//GEN-LAST:event_jTextFieldUsernameMouseExited

    private void jTextFieldUsernameMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTextFieldUsernameMouseEntered
        jTextFieldUsername.setBackground(Color.white);
    }//GEN-LAST:event_jTextFieldUsernameMouseEntered

    private void jTextFieldPasswordMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTextFieldPasswordMouseEntered
        jTextFieldPassword.setBackground(Color.white);
    }//GEN-LAST:event_jTextFieldPasswordMouseEntered

    private void jTextFieldPasswordMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTextFieldPasswordMouseExited
        jTextFieldPassword.setBackground(new Color(0xCCCCCC));
    }//GEN-LAST:event_jTextFieldPasswordMouseExited

    private void jButtonLoginKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jButtonLoginKeyPressed
      
    }//GEN-LAST:event_jButtonLoginKeyPressed

    private void jButtonCancelKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jButtonCancelKeyPressed
      
    }//GEN-LAST:event_jButtonCancelKeyPressed

    private void jTextFieldPasswordMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTextFieldPasswordMouseReleased
        jLabelPassword.setText("");
    }//GEN-LAST:event_jTextFieldPasswordMouseReleased

    private void jButtonRegisterNowActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonRegisterNowActionPerformed
    
        RegisterForm registerForm = new RegisterForm();
        registerForm.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButtonRegisterNowActionPerformed

    private void jButtonRegisterNowKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jButtonRegisterNowKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButtonRegisterNowKeyPressed

    
    public static void main(String args[])  {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new LoginForm().setVisible(true);
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(LoginForm.class.getName()).log(Level.SEVERE, null, ex);
                } catch (SQLException ex) {
                    Logger.getLogger(LoginForm.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }
private String username,password;
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JButton jButtonCancel;
    private javax.swing.JButton jButtonLogin;
    private javax.swing.JButton jButtonRegisterNow;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabelPassword;
    private javax.swing.JLabel jLabelUsername;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPasswordField jTextFieldPassword;
    private javax.swing.JTextField jTextFieldUsername;
    private javax.swing.JLabel usernameTextFeild;
    private javax.swing.JLabel usernameTextFeild1;
    // End of variables declaration//GEN-END:variables
}
