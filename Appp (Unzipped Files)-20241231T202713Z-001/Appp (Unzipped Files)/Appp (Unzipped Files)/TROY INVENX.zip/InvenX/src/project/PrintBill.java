/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import models.Printables;
import models.Products;
import Connection.DBConnection;
import java.util.Calendar;
import java.util.GregorianCalendar;

/**
 *
 * @author honey's here
 */
public class PrintBill extends javax.swing.JFrame {
    
    private PreparedStatement ps;
    private ResultSet rs;
    private Connection connection;
    private DefaultTableModel model;
    boolean flag;

    public PrintBill() {
        initComponents();
        this.setLocationRelativeTo(this);
        tableAlignment();
        DefaultTableModel model = (DefaultTableModel) jTablePrintable.getModel();
        model.setRowCount(0);
        
        showTable();
        
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTablePrintable = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jLabelCalculateAndInsert = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabelTotalAmount = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jTablePrintable.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jTablePrintable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "ID", "Name", "No. of Product", "Price"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                true, false, true, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTablePrintable.setColumnSelectionAllowed(true);
        jTablePrintable.setRowHeight(20);
        jScrollPane1.setViewportView(jTablePrintable);
        jTablePrintable.getColumnModel().getSelectionModel().setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        if (jTablePrintable.getColumnModel().getColumnCount() > 0) {
            jTablePrintable.getColumnModel().getColumn(0).setResizable(false);
            jTablePrintable.getColumnModel().getColumn(0).setPreferredWidth(50);
            jTablePrintable.getColumnModel().getColumn(1).setResizable(false);
            jTablePrintable.getColumnModel().getColumn(2).setResizable(false);
            jTablePrintable.getColumnModel().getColumn(2).setPreferredWidth(80);
            jTablePrintable.getColumnModel().getColumn(3).setResizable(false);
        }

        jButton1.setBackground(new java.awt.Color(255, 0, 51));
        jButton1.setText("Cancel");
        jButton1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton1MouseClicked(evt);
            }
        });

        jButton2.setBackground(new java.awt.Color(51, 255, 0));
        jButton2.setText("Print Bill");
        jButton2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton2MouseClicked(evt);
            }
        });

        jLabelCalculateAndInsert.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabelCalculateAndInsert.setForeground(new java.awt.Color(51, 51, 255));
        jLabelCalculateAndInsert.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabelCalculateAndInsert.setText("Calculate & Insert Sellings");
        jLabelCalculateAndInsert.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabelCalculateAndInsertMouseClicked(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Total:");

        jLabelTotalAmount.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabelTotalAmount.setText("0");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 571, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabelCalculateAndInsert)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addComponent(jButton1)
                                .addGap(18, 18, 18)
                                .addComponent(jButton2))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addGap(18, 18, 18)
                                .addComponent(jLabelTotalAmount, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 392, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jLabelTotalAmount))
                .addGap(20, 20, 20)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabelCalculateAndInsert, javax.swing.GroupLayout.DEFAULT_SIZE, 37, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton2MouseClicked
//        if (flag == true) {
            MessageFormat header = new MessageFormat("Report File");
        MessageFormat footer = new MessageFormat("page{0,number,integer}");
        try {
            jTablePrintable.print(JTable.PrintMode.FIT_WIDTH, header, footer);
            showTable();
        } catch (java.awt.print.PrinterException e) {
            System.err.println("Cannot Print%s%n"+e.getMessage());
        }
        
//        }else{
//            JOptionPane.showMessageDialog(null,"Firstly you have to calculate bill.");
//        }
    }//GEN-LAST:event_jButton2MouseClicked

    private void jButton1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton1MouseClicked
        int n = JOptionPane.showConfirmDialog(
            null,
            "Are you sure!",
            "Close",
            JOptionPane.YES_NO_OPTION);
        if(n==JOptionPane.YES_NO_OPTION){
            try {
                MainMenu mainDataForm = new MainMenu();
                mainDataForm.setVisible(true);
                this.dispose();
            } catch (ClassNotFoundException | SQLException ex) {
                Logger.getLogger(PrintBill.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }//GEN-LAST:event_jButton1MouseClicked

    private void jLabelCalculateAndInsertMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabelCalculateAndInsertMouseClicked

        int n = JOptionPane.showConfirmDialog(
            null,
            "Are you sure to Calculate Bill",
            "Calculate Bill",
            JOptionPane.YES_NO_OPTION);
        if(n==JOptionPane.YES_NO_OPTION){
            new Thread().run();
        }
        
    }//GEN-LAST:event_jLabelCalculateAndInsertMouseClicked

    public void tableAlignment(){
        DefaultTableCellRenderer rightRenderer = new DefaultTableCellRenderer();
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        rightRenderer.setHorizontalAlignment(JLabel.RIGHT);
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);
        jTablePrintable.getColumnModel().getColumn(2).setCellRenderer(centerRenderer);
        jTablePrintable.getColumnModel().getColumn(3).setCellRenderer(rightRenderer);
        jTablePrintable.getColumnModel().getColumn(0).setCellRenderer(centerRenderer);
    }
    
    public void showTable(){
        model = (DefaultTableModel) jTablePrintable.getModel();
        for(int i=0 ; i<16;i++){
            model.insertRow(jTablePrintable.getRowCount(),new Object[]{"","","","",""});
        }
        flag = false;
    }
    
    public void addToSell() throws ClassNotFoundException, SQLException{
        double buyingPrice = 0;
        String name = null;
        int id = 0,totalQuantity,quantityLeft;
        double total = 0;
        double singlePrice = 0;
        int noOfProducts = 0;
        for (int i = 0; i <= jTablePrintable.getRowCount(); i++) {
            for (int j = 0; j <= jTablePrintable.getColumnCount(); j++) {
                if (j==0) {
                    id = Integer.parseInt((String) jTablePrintable.getValueAt(i, j));
                    buyingPrice = Double.parseDouble(getBuyingPrice(id));
                    name = getName(id);
                }
                if(j==1){
                    jTablePrintable.setValueAt(name, i, j);
                }
                if (j==2) {
                    noOfProducts = Integer.parseInt((String) jTablePrintable.getValueAt(i, j));
                    singlePrice = Double.parseDouble(getSellingPrice(id));
                    total =total + (singlePrice*noOfProducts);
                    totalQuantity = getQuantity(id);
                    if (noOfProducts<totalQuantity) {
                        quantityLeft = totalQuantity - noOfProducts;
                        insertIntoProfitSheet(name, singlePrice,buyingPrice,noOfProducts);
                        updateQuantityInMain(id, quantityLeft);
                    }else {
                        JOptionPane.showMessageDialog(null,"You have only "+totalQuantity+" Quantity of "+name+" Left");
                    }
                }
                if(j==3){
                    jTablePrintable.setValueAt(String.valueOf(singlePrice), i, j);
                }
            }
            jLabelTotalAmount.setText(String.valueOf(total)+" Rs");
        }
    }
    
    public String getBuyingPrice(int id){
        String buyingPrice = null;
        try {
            connection = DBConnection.connect();
            ps = connection.prepareStatement("select *from Products where p_id = '"+id+"';");
            rs = ps.executeQuery();
            while(rs.next()){
                buyingPrice = rs.getString("buying_price");
            }
        } catch (ClassNotFoundException | SQLException e) {
            System.err.println(e.getMessage());
        }finally{
            try {
                connection.close();
                ps.close();
                rs.close();
            } catch (Exception e) {
            }
        }
        return buyingPrice;
    }
    
    public String getSellingPrice(int id){
        String sellingPrice = null;
        try {
            connection = DBConnection.connect();
            ps = connection.prepareStatement("select *from Products where p_id = '"+id+"';");
            rs = ps.executeQuery();
            while(rs.next()){
                sellingPrice = rs.getString("selling_price");
            }
        } catch (ClassNotFoundException | SQLException e) {
            System.err.println(e.getMessage());
        }finally{
            try {
                connection.close();
                ps.close();
                rs.close();
            } catch (Exception e) {
            }
        }
        return sellingPrice;
    }
    
    public String getName(int id){
        String name = null;
        try {
            connection = DBConnection.connect();
            ps = connection.prepareStatement("select *from Products where p_id = '"+id+"';");
            rs = ps.executeQuery();
            while(rs.next()){
                name = rs.getString("product_name");
            }
        } catch (ClassNotFoundException | SQLException e) {
            System.err.println(e.getMessage());
        }finally{
            try {
                connection.close();
                ps.close();
                rs.close();
            } catch (Exception e) {
            }
        }
        return name;
    }
    
    public int getQuantity(int id){
        int quantity = 0;
        try {
            connection = DBConnection.connect();
            ps = connection.prepareStatement("select *from Products where p_id = '"+id+"';");
            rs = ps.executeQuery();
            while(rs.next()){
                quantity = Integer.parseInt(rs.getString("product_left"));
            }
        } catch (ClassNotFoundException | SQLException e) {
            System.err.println(e.getMessage());
        }finally{
            try {
                connection.close();
                ps.close();
                rs.close();
            } catch (Exception e) {
            }
        }
        return quantity;
    }
    
    public void updateQuantityInMain(int id,int quantity) throws ClassNotFoundException, SQLException{
        connection = DBConnection.connect();
        try {
                     ps = connection.prepareStatement("update Products set product_left = ? "
                             + "where p_id = ?;");
                     if(id==0){
                         JOptionPane.showMessageDialog(null,"Please Enter Name...");
                     }else{
                     ps.setString(1, String.valueOf(quantity));
                     }
                     ps.setInt(2, id);
                     ps.executeUpdate();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null,e.getMessage());
            }finally{
                try {
                    ps.close();
                    connection.close();
                } catch (SQLException ex) {
                    Logger.getLogger(DataMaintain.class.getName()).log(Level.SEVERE, null, ex);
                }
    }
    }
    
//    public ArrayList<Printables> printableList() throws ClassNotFoundException, SQLException{
//        ArrayList<Printables> printableList = new ArrayList<>();
//        connection = DBConnection.connect();
//        try{
//                ps = connection.prepareStatement("select *from Sellings_Profit");
//                rs = ps.executeQuery();
//                Printables printable;
//                while(rs.next()){
//                    printable = new Printables(rs.getInt("report_id"),
//                            rs.getString("date"),
//                            rs.getString("product_name"),
//                            rs.getString("sellings"),
//                            rs.getString("profit"));
//                    printableList.add(printable);
//                }
//        }catch (SQLException e) {
//                JOptionPane.showMessageDialog(null,e.getMessage());
//            }
//        finally{
//            try {
//                ps.close();
//                rs.close();
//                connection.close();
//                System.out.print("connection is closed");
//                } catch (SQLException ex) {
//                    Logger.getLogger(MainMenu.class.getName()).log(Level.SEVERE, null, ex);
//                }
//            
//        }
//        return printableList;
//    }
//    
//    public void showPrintables(){
//        try{
//        ArrayList<Printables> list = printableList();
//        DefaultTableModel model = (DefaultTableModel) jTablePrintable.getModel();
//        Object[] row = new Object[5];
//        list.stream().map((list1) -> {
//            row[0] = list1.getId();
//            return list1;
//            }).map((list1) -> {
//                row[1] = list1.getDate();
//                return list1;
//            }).map((list1) -> {
//                row[2] = list1.getProductName();
//                return list1;
//            }).map((list1) -> {
//                row[3] = list1.getSellings()+" $";
//                return list1;
//            }).map((list1) -> {
//                row[4] = list1.getProfit()+" $";
//                return list1;
//            }).forEach((_item) -> {
//                model.addRow(row);
//            });
//        }catch(ClassNotFoundException | SQLException e){
//            
//        }
//    }
    
    public void insertIntoProfitSheet(String name,
            double sellingPrice,
            double buyingPrice,
            double quantity) throws ClassNotFoundException, SQLException{
        connection = DBConnection.connect();
        try {
                     ps = connection.prepareStatement("insert into Sellings_Profit(report_id,"
                             + "date,"
                             + "product_name,"
                             + "sellings,"
                             + "profit)"
                        + "values(?,?,?,?,?)");
                     Calendar date = new GregorianCalendar();
                     int month = date.get(Calendar.MONTH);
                     int year = date.get(Calendar.YEAR);
                     int day = date.get(Calendar.DAY_OF_MONTH);
                     if (month+1<10){
                        ps.setString(2, String.valueOf(year+"-"+"0"+(month+1)+"-"+day));
                     } else {
                    ps.setString(2, String.valueOf(year+"-"+(month+1)+"-"+day));
                     }
                     ps.setString(3, name);
                     double sellings = sellingPrice * quantity;
                     ps.setString(4, String.valueOf(sellings));
                      double buyings = buyingPrice * quantity;
                     double profit = sellings-buyings;
                     ps.setString(5, String.valueOf(profit));
                     ps.executeUpdate();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null,e.getMessage());
            }finally{
                try {
                    ps.close();
                    connection.close();
                } catch (SQLException ex) {
                    Logger.getLogger(DataMaintain.class.getName()).log(Level.SEVERE, null, ex);
                }
    }
    }
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PrintBill.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PrintBill.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PrintBill.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PrintBill.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PrintBill().setVisible(true);
            }
        });
    }
    
    public class Thread implements Runnable {

        @Override
        public void run() {
            try {
                addToSell();
                flag = true;
            } catch (ClassNotFoundException | SQLException ex) {
                Logger.getLogger(DataMaintain.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabelCalculateAndInsert;
    private javax.swing.JLabel jLabelTotalAmount;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTablePrintable;
    // End of variables declaration//GEN-END:variables
}
