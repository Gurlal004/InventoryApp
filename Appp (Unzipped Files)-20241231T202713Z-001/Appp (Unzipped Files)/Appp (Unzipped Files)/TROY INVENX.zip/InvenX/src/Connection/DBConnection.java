package Connection;

import java.sql.*;
import java.util.logging.Level;
import javax.swing.JOptionPane;
import javax.swing.SwingWorker;
public class DBConnection{
    private static Connection conn = null;
    public static Statement statement;
    public static Connection connect() throws ClassNotFoundException, SQLException{
        
        try {
            Class.forName("org.sqlite.JDBC");
            String connectionUrl = "jdbc:sqlite:my_db.db";
            conn = DriverManager.getConnection(connectionUrl);
            statement = conn.createStatement();
            System.out.println("Connected");
        } catch (SQLException e){
            JOptionPane.showMessageDialog(null, e);
        }
        return conn;
    }
    
    public static boolean tableExists(String tableName) throws ClassNotFoundException, SQLException{
        connect();
        try {
                String tableExists = "SELECT *FROM "
                        + tableName+";"; 
                Statement statement = conn.createStatement();
                ResultSet ex = statement.executeQuery(tableExists);
                String exS = ex.getString(1);
                System.out.println("Table " + tableName + " exists.");
                return true;
            }catch (SQLException e){
                    return false;
                }
    }
    
    public static void DbChecker() throws ClassNotFoundException, SQLException{
        
        try {
            if(!tableExists("Products")){
            PreparedStatement ps = conn.prepareStatement("create table Products(p_id INTEGER PRIMARY KEY autoincrement,"
                + "product_name varchar(255),"
                + "buying_price varchar(255),"
                + "selling_price varchar(255),"
                + "product_left varchar(255));");
            ps.executeUpdate();
            System.out.println("Table is created");
        }
            
            
        } catch (ClassNotFoundException | SQLException e) {
        }   finally{
            conn.close();
        }     
        
        try {
            if(!tableExists("Sellings_Profit")){
            PreparedStatement ps = conn.prepareStatement("create table Sellings_Profit(report_id INTEGER PRIMARY KEY autoincrement,"
                + "date varchar(255),"
                + "product_name varchar(255),"
                + "sellings varchar(255),"
                + "profit varchar(255));");
            ps.executeUpdate();
            System.out.println("Table is created");
        }
        } catch (ClassNotFoundException | SQLException e) {
        }   finally{
            conn.close();
        }
        
        try {
            if(!tableExists("UserCredentials")){
            PreparedStatement ps = conn.prepareStatement("create table UserCredentials(user_id INTEGER PRIMARY KEY autoincrement,"
                + "username varchar(255),"
                + "password varchar(255));");
            ps.executeUpdate();
            System.out.println("Table is created");
        }
        } catch (ClassNotFoundException | SQLException e) {
        }   finally{
            conn.close();
        }
    }
}